package w3schoolPracJava;

public class ObjectArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int a [] = new  int [5];
     a[0]=2;
     System.out.println(a[0]);
     
     Object ar [] = new Object [3];
     // we use object array in java for diff data types
     // and array list for resize the array
     String ar [0] ;
     
     
     
	}

}
