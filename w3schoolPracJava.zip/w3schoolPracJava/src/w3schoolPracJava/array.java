package w3schoolPracJava;

public class array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 {
			    int[][] myNumbers = { {1, 2, 3, 4}, {5, 6, 7} };
			    int x = myNumbers[1][2];
			    System.out.println(x);  
			  }

	}

}

