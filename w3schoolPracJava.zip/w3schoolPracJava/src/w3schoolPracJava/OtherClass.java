package w3schoolPracJava;

public class OtherClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
			  
			    Car myCar = new Car();     // Create a myCar object
			    myCar.fullThrottle();      // Call the fullThrottle() method
			    myCar.speed(200);          // Call the speed() method
			    //myMethod(); static methods cant be used in the dofferent class by directly call
			    Car.myMethod(); // we can use it by class name
			  }
			}
	


