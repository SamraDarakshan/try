package w3schoolPracJava.MultipleInterface;


class MyMainClass {
	  public static void main(String[] args) {
	    DemoClass myObj = new DemoClass();
	    myObj.myMethod();
	    myObj.myOtherMethod();
	  }
	}