package w3schoolPracJava.MultipleInterface;

public interface SecondInterface {
	public void myOtherMethod(); // interface method
}
