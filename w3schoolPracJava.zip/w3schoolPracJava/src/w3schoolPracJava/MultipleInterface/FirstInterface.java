package w3schoolPracJava.MultipleInterface;

public interface FirstInterface {
	  public void myMethod(); // interface metho
}
