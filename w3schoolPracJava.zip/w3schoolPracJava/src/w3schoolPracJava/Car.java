package w3schoolPracJava;

public class Car {

		  public void fullThrottle() {
		    System.out.println("The car is going as fast as it can!");
		  }

		  public void speed(int maxSpeed) {
		    System.out.println("Max speed is: " + maxSpeed);
		  }
		  
		static void myMethod() {
			    System.out.println("I just got executed!");
			  } 
		  
		  /*we can used static method or attribute within  same class because if there is dfferent classe
		  we need object and in static there is object creation */
		// it can be call by class name
		}
	

