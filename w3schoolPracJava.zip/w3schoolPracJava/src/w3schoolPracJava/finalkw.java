package w3schoolPracJava;

public class finalkw {
	int x = 10;
 //final int x = 10; if we five final i will not change and goves error , final is one of modifier
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
		
		
				  finalkw myObj = new finalkw();
			      myObj.x = 25; // will generate an error
			    System.out.println(myObj.x); 
			  }
			}

	


