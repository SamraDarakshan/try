package w3schoolPracJava.polymorphisim;

class Animal {
	  public void animalSound() {
	    System.out.println("The animal makes a sound");
	  }
	  public int notoverride(int x){
		  return x;
	  }
	}
