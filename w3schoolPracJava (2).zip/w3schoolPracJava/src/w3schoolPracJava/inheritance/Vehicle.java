package w3schoolPracJava.inheritance;

class Vehicle {
	  protected  String brand = "Ford";         // Vehicle attribute
	  public void honk() {                     // Vehicle method
	    System.out.println("Tuut, tuut!");
	  }
	}