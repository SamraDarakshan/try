package w3schoolPracJava.Abstract;

	// Code from filename: Person.java 
	// abstract class
	abstract class Person {
	  public String fname = "John";
	  public int age = 24;
	  public abstract void study(); // abstract method 
	}

