package w3schoolPracJava;

public class PassByRef {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
using namespace std;
void process(int& value) {
    cout << "Value passed into function: " << value << endl;
    value = 10;
    cout << "Value before leaving function: " << value << endl;
}
int main() {
    int someValue = 7;
    cout << "Value before function call: " << someValue << endl;
    process(someValue);
    cout << "Value after function call: " << someValue << endl;
    return 
    		If we run this code, we obtain the following output:
    			Value before function call: 7                                                                                                                                                    
    			Value passed into function: 7                                                                                                                                                    
    			Value before leaving function: 10                                                                                                                                                
    			Value after function call: 10
