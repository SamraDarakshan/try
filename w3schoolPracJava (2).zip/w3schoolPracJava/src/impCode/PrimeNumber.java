package impCode;
import java.util.Scanner;





public class PrimeNumber {



	 public static void main(String args[]){ 
		 System.out.println("How many numbers you want to check?"); 
		 Scanner obj = new Scanner(System.in);
		 int num = obj.nextInt();
		 
     for (int j=0; j<num; j++ ){
	 System.out.println("Enter the number you want to check");

	 int n = obj.nextInt();
		int i,flag=0;      
		 // int n=3;//it is the number to be checked    
			 int m=n/2;       // e.g1 if n=2 , 0=2/2=1 reemainder is yani m ki value hogai 1, and remainder is 0
			               //e.g3 if n=3 , 3/2=1 and remainder is 1
			               //e.g3 if n=4 4/2= 2 and remainder is 2
		  if(n==0||n==1){  
		   System.out.println(n+" is not prime number");      	
		   }
		  else{                        //e.g 1
		   for(i=2;i<=m;i++){       //i=2 2 is not less than equal to m=1 so it will not check the condition
			    if(n%i==0){        // loop se bhr aya flag 0 he tha print 2 is prime
			                        //e.g 2: i=2, 2<=1 not go down from the loop print 3 is prime
			    	                 //e.g 3:i=2 i<=m means 2<=2 yes go inside check 
			    	               //if n%i==0 means 2/2=1 remainder is 0 true 4 is not prime
			    	              // flag=1, break
			    	
			    	                 
			    	
		     System.out.println(n+" is not prime number");      
		     flag=1;      
			     break;      
			    }      
			   }      
			   if(flag==0)  { System.out.println(n+" is prime number"); }  
			  }//end of else  
     }
		 

	}    
}