package impCode;


	import java.util.*;
 
	class ReverseString
	{
	   public static void main(String args[])
	   {
	      String original, reverse = ""; // means an empty string
	      Scanner in = new Scanner(System.in);
	     
	      System.out.println("Enter a string to reverse");
	      original = in.nextLine();
	     
	      int length = original.length();
	     //samra= 5 -1 =4, 4 to 0
	      for (int i = length - 1 ; i >= 0 ; i--)
	         reverse = reverse + original.charAt(i);
	      // okay so if we not gives empty and use like reverse= original.chartAt(i) it will
	      //give type cast error string to char so its must to add it
	         
	      System.out.println("Reverse of the string: " + reverse);
	   }
	}
