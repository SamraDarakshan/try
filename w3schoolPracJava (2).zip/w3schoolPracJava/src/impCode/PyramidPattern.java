package impCode;
import java.io.*;
public class PyramidPattern {

	 
	
	    // Function to demonstrate printing pattern 
	    public static void printStars(int n) 
	    { 
	        int i, j; 
	  
	        // outer loop to handle number of rows 
	        //  n in this case 
	        for(i=0; i<n; i++) 
	        { 
	  
	            //  inner loop to handle number of columns 
	            //  values changing acc. to outer loop     
	            for(j=0; j<=i; j++) 
	            { 
	                // printing stars 
	                System.out.print("* "); 
	            } 
	  
	            // ending line after each row 
	            System.out.println(); 
	        } 
	   } 
	  
	    // Driver Function 
	    public static void main(String args[]) 
	    { 
	        int n = 5; 
	        printStars(n); 
	    } 
	} 
/*
e
edit
play_arrow

brightness_4
import java.io.*; 
  
// Java code to demonstrate star pattern 
public class GeeksForGeeks 
{ 
    // Function to demonstrate printing pattern 
    public static void printStars(int n) 
    { 
        int i, j; 
  
        // outer loop to handle number of rows 
        //  n in this case 
        for(i=0; i<n; i++) 
        { 
  
            // inner loop to handle number spaces 
            // values changing acc. to requirement 
            for(j=2*(n-i); j>=0; j--) 
            { 
                // printing spaces 
                System.out.print(" "); 
            } 
             
            //  inner loop to handle number of columns 
            //  values changing acc. to outer loop 
            for(j=0; j<=i; j++) 
            { 
                // printing stars 
                System.out.print("* "); 
            } 
              
            // ending line after each row 
            System.out.println(); 
        } 
    } 
  
    // Driver Function 
    public static void main(String args[]) 
    { 
        int n = 5; 
        printStars(n); 
    } 
} 
Output:

        *
      * * 
    * * * 
  * * * * 
* * * * * 

Printing Triangle

filter_none
edit
play_arrow

brightness_4
import java.io.*; 
  
// Java code to demonstrate star pattern 
public class GeeksForGeeks 
{ 
    // Function to demonstrate printing pattern 
    public static void printTriagle(int n) 
    { 
        // outer loop to handle number of rows 
        //  n in this case 
        for (int i=0; i<n; i++) 
        { 
  
            // inner loop to handle number spaces 
            // values changing acc. to requirement 
            for (int j=n-i; j>1; j--) 
            { 
                // printing spaces 
                System.out.print(" "); 
            } 
   
            //  inner loop to handle number of columns 
            //  values changing acc. to outer loop 
            for (int j=0; j<=i; j++ ) 
            { 
                // printing stars 
                System.out.print("* "); 
            } 
   
            // ending line after each row 
            System.out.println(); 
        } 
    } 
      
    // Driver Function 
    public static void main(String args[]) 
    { 
        int n = 5; 
        printTriagle(n); 
    } 
} 
Output:

    * 
   * * 
  * * * 
 * * * * 
* * * * * 

Number Pattern

filter_none
edit
play_arrow

brightness_4
import java.io.*; 
  
// Java code to demonstrate number pattern 
public class GeeksForGeeks 
{ 
    // Function to demonstrate printing pattern 
    public static void printNums(int n) 
    { 
        int i, j,num; 
  
        // outer loop to handle number of rows 
        //  n in this case 
        for(i=0; i<n; i++) 
        { 
            // initialising starting number 
            num=1; 
  
            //  inner loop to handle number of columns 
            //  values changing acc. to outer loop 
            for(j=0; j<=i; j++) 
            { 
                // printing num with a space  
                System.out.print(num+ " "); 
  
                //incrementing value of num 
                num++; 
            } 
  
            // ending line after each row 
            System.out.println(); 
        } 
    } 
  
    // Driver Function 
    public static void main(String args[]) 
    { 
        int n = 5; 
        printNums(n); 
    } 
} 
Output:

1 
1 2 
1 2 3 
1 2 3 4 
1 2 3 4 5 
*/
